export interface User {
  id: string;
  email: string;
  name: string;
  role: 'student' | 'senior' | 'moderator';
  year: number;
  branch: string;
  avatar?: string;
  interests: string[];
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  category: 'academic' | 'exams' | 'scholarships' | 'events' | 'general';
  isImportant: boolean;
  createdAt: Date;
  deadline?: Date;
  author: string;
}

export interface Post {
  id: string;
  content: string;
  author: User;
  community: string;
  likes: number;
  comments: number;
  createdAt: Date;
  tags: string[];
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  createdAt: Date;
  isAnonymous: boolean;
}

export interface CPProblem {
  id: string;
  title: string;
  platform: 'leetcode' | 'codeforces' | 'codechef' | 'hackerrank';
  difficulty: 'easy' | 'medium' | 'hard';
  url: string;
  date: Date;
  solvedBy: string[];
}

export interface MessMenu {
  id: string;
  date: Date;
  breakfast: string[];
  lunch: string[];
  snacks: string[];
  dinner: string[];
  rating: number;
  votes: number;
}

export interface Complaint {
  id: string;
  title: string;
  description: string;
  category: 'academic' | 'hostel' | 'mess' | 'infrastructure' | 'other';
  status: 'pending' | 'in-progress' | 'resolved' | 'rejected';
  createdAt: Date;
  authorId: string;
  isAnonymous: boolean;
  upvotes: number;
}

export interface Community {
  id: string;
  name: string;
  description: string;
  icon: string;
  memberCount: number;
  category: 'tech' | 'cultural' | 'sports' | 'academic';
}
