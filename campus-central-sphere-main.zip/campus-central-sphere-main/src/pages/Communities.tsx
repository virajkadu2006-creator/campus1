import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { CommunityCard } from '@/components/cards/CommunityCard';
import { PostCard } from '@/components/cards/PostCard';
import { communities, posts } from '@/data/mockData';
import { 
  Users, 
  Search, 
  Plus, 
  TrendingUp,
  Sparkles,
  Send
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const categories = ['all', 'tech', 'cultural', 'sports', 'academic'] as const;

export default function Communities() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [newPost, setNewPost] = useState('');

  const filteredCommunities = selectedCategory === 'all'
    ? communities
    : communities.filter(c => c.category === selectedCategory);

  const handlePost = () => {
    if (newPost.trim()) {
      toast.success('Post published successfully!');
      setNewPost('');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold flex items-center gap-2">
            <Users className="h-6 w-6 text-primary" />
            Communities
          </h1>
          <p className="text-muted-foreground mt-1">
            Connect with clubs, groups, and fellow students
          </p>
        </div>
        <div className="relative max-w-xs w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search communities..." className="pl-9" />
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Create Post */}
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <Textarea
                  placeholder="Share something with the community..."
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  className="resize-none"
                  rows={3}
                />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="gap-1">
                      <Sparkles className="h-3 w-3" />
                      House of Geeks
                    </Badge>
                  </div>
                  <Button onClick={handlePost} disabled={!newPost.trim()} className="gap-2">
                    <Send className="h-4 w-4" />
                    Post
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Community Feed */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Trending in Communities
              </h2>
            </div>
            <div className="space-y-4">
              {posts.map(post => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar - Communities List */}
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Explore Communities</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="all" onValueChange={setSelectedCategory}>
                <TabsList className="w-full mb-4">
                  <TabsTrigger value="all" className="flex-1">All</TabsTrigger>
                  <TabsTrigger value="tech" className="flex-1">Tech</TabsTrigger>
                  <TabsTrigger value="cultural" className="flex-1">Cultural</TabsTrigger>
                </TabsList>

                <TabsContent value={selectedCategory} className="mt-0">
                  <div className="space-y-3">
                    {filteredCommunities.map(community => (
                      <div 
                        key={community.id}
                        className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors cursor-pointer"
                      >
                        <div className={cn(
                          "h-10 w-10 rounded-lg flex items-center justify-center text-lg",
                          community.category === 'tech' && "bg-campus-blue/10",
                          community.category === 'cultural' && "bg-campus-purple/10",
                          community.category === 'sports' && "bg-campus-green/10",
                          community.category === 'academic' && "bg-campus-orange/10"
                        )}>
                          {community.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{community.name}</p>
                          <p className="text-xs text-muted-foreground">{community.memberCount} members</p>
                        </div>
                        <Button variant="outline" size="sm">Join</Button>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Your Communities */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Your Communities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {communities.slice(0, 3).map(community => (
                  <div 
                    key={community.id}
                    className="flex items-center gap-3"
                  >
                    <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center text-sm">
                      {community.icon}
                    </div>
                    <span className="font-medium text-sm">{community.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
