import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { NoticeCard } from '@/components/cards/NoticeCard';
import { notices } from '@/data/mockData';
import { Bell, Filter, AlertTriangle } from 'lucide-react';

const categories = ['all', 'academic', 'exams', 'scholarships', 'events', 'general'] as const;

export default function Notices() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredNotices = selectedCategory === 'all' 
    ? notices 
    : notices.filter(n => n.category === selectedCategory);

  const importantNotices = filteredNotices.filter(n => n.isImportant);
  const regularNotices = filteredNotices.filter(n => !n.isImportant);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold flex items-center gap-2">
            <Bell className="h-6 w-6 text-primary" />
            Notice Board
          </h1>
          <p className="text-muted-foreground mt-1">
            Stay updated with all college announcements
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1.5">
            <AlertTriangle className="h-3 w-3 text-campus-orange" />
            {importantNotices.length} Important
          </Badge>
        </div>
      </div>

      {/* Category Filter */}
      <Tabs defaultValue="all" onValueChange={setSelectedCategory}>
        <TabsList className="bg-muted/50 p-1">
          {categories.map(cat => (
            <TabsTrigger 
              key={cat} 
              value={cat}
              className="capitalize data-[state=active]:bg-background data-[state=active]:shadow-sm"
            >
              {cat}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value={selectedCategory} className="mt-6">
          {/* Important Notices */}
          {importantNotices.length > 0 && (
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-campus-orange" />
                Important Notices
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                {importantNotices.map(notice => (
                  <NoticeCard key={notice.id} notice={notice} />
                ))}
              </div>
            </div>
          )}

          {/* Regular Notices */}
          <div>
            <h2 className="text-lg font-semibold mb-4">All Notices</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {regularNotices.map(notice => (
                <NoticeCard key={notice.id} notice={notice} />
              ))}
            </div>
          </div>

          {filteredNotices.length === 0 && (
            <Card className="py-12">
              <CardContent className="text-center">
                <Bell className="h-12 w-12 text-muted-foreground/40 mx-auto mb-4" />
                <p className="text-muted-foreground">No notices in this category</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
