import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { StatsCard } from '@/components/cards/StatsCard';
import { complaints } from '@/data/mockData';
import { 
  FileText, 
  Plus, 
  ThumbsUp, 
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Send,
  EyeOff,
  TrendingUp,
  Users,
  BarChart3
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';

const statusConfig = {
  pending: { label: 'Pending', icon: Clock, color: 'bg-campus-orange/10 text-campus-orange border-campus-orange/20' },
  'in-progress': { label: 'In Progress', icon: AlertCircle, color: 'bg-campus-blue/10 text-campus-blue border-campus-blue/20' },
  resolved: { label: 'Resolved', icon: CheckCircle2, color: 'bg-campus-green/10 text-campus-green border-campus-green/20' },
  rejected: { label: 'Rejected', icon: XCircle, color: 'bg-destructive/10 text-destructive border-destructive/20' },
};

const categoryConfig = {
  academic: { label: 'Academic', color: 'bg-campus-blue/10 text-campus-blue' },
  hostel: { label: 'Hostel', color: 'bg-campus-purple/10 text-campus-purple' },
  mess: { label: 'Mess', color: 'bg-campus-orange/10 text-campus-orange' },
  infrastructure: { label: 'Infrastructure', color: 'bg-campus-green/10 text-campus-green' },
  other: { label: 'Other', color: 'bg-muted text-muted-foreground' },
};

export default function Complaints() {
  const [showNewComplaint, setShowNewComplaint] = useState(false);
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');

  const pendingCount = complaints.filter(c => c.status === 'pending').length;
  const inProgressCount = complaints.filter(c => c.status === 'in-progress').length;
  const resolvedCount = complaints.filter(c => c.status === 'resolved').length;

  const handleSubmit = () => {
    if (title && description && category) {
      toast.success('Complaint submitted successfully!');
      setShowNewComplaint(false);
      setTitle('');
      setDescription('');
      setCategory('');
      setIsAnonymous(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold flex items-center gap-2">
            <FileText className="h-6 w-6 text-primary" />
            Student Council & Complaints
          </h1>
          <p className="text-muted-foreground mt-1">
            Submit complaints and track their status
          </p>
        </div>
        <Button onClick={() => setShowNewComplaint(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          New Complaint
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatsCard
          title="Total Complaints"
          value={complaints.length}
          icon={BarChart3}
          variant="primary"
        />
        <StatsCard
          title="Pending"
          value={pendingCount}
          icon={Clock}
          variant="warning"
        />
        <StatsCard
          title="In Progress"
          value={inProgressCount}
          icon={AlertCircle}
        />
        <StatsCard
          title="Resolved"
          value={resolvedCount}
          icon={CheckCircle2}
          variant="accent"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* New Complaint Form */}
          {showNewComplaint && (
            <Card className="border-primary/20 shadow-lg">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Submit New Complaint</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    placeholder="Brief title of your complaint"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="academic">Academic</SelectItem>
                      <SelectItem value="hostel">Hostel</SelectItem>
                      <SelectItem value="mess">Mess</SelectItem>
                      <SelectItem value="infrastructure">Infrastructure</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe your complaint in detail..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={4}
                  />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2">
                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Submit anonymously</span>
                  </div>
                  <Switch
                    checked={isAnonymous}
                    onCheckedChange={setIsAnonymous}
                  />
                </div>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setShowNewComplaint(false)} className="flex-1">
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleSubmit} 
                    disabled={!title || !description || !category}
                    className="flex-1 gap-2"
                  >
                    <Send className="h-4 w-4" />
                    Submit
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Complaints List */}
          <Tabs defaultValue="all">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="in-progress">In Progress</TabsTrigger>
              <TabsTrigger value="resolved">Resolved</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-4 space-y-4">
              {complaints.map((complaint) => (
                <ComplaintCard key={complaint.id} complaint={complaint} />
              ))}
            </TabsContent>

            {['pending', 'in-progress', 'resolved'].map((status) => (
              <TabsContent key={status} value={status} className="mt-4 space-y-4">
                {complaints
                  .filter((c) => c.status === status)
                  .map((complaint) => (
                    <ComplaintCard key={complaint.id} complaint={complaint} />
                  ))}
              </TabsContent>
            ))}
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Council Announcements */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Council Updates
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                <p className="text-sm font-medium">Infrastructure Audit</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Complete infrastructure audit scheduled for next week. Submit pending complaints.
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-sm font-medium">Mess Committee Meeting</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Monthly mess feedback session on Friday at 5 PM.
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-sm font-medium">Election Results</p>
                <p className="text-xs text-muted-foreground mt-1">
                  New student council elected. Meet your representatives!
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Transparency Dashboard */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Transparency Stats
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Resolution Rate</span>
                  <span className="font-bold text-campus-green">78%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Avg. Response Time</span>
                  <span className="font-bold">2.3 days</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">This Month</span>
                  <span className="font-bold">{complaints.length} complaints</span>
                </div>
                <div className="pt-3 border-t">
                  <p className="text-xs text-muted-foreground text-center">
                    Data updated in real-time
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function ComplaintCard({ complaint }: { complaint: typeof complaints[0] }) {
  const [upvotes, setUpvotes] = useState(complaint.upvotes);
  const [hasUpvoted, setHasUpvoted] = useState(false);
  const status = statusConfig[complaint.status];
  const categoryStyle = categoryConfig[complaint.category];

  const handleUpvote = () => {
    if (!hasUpvoted) {
      setUpvotes(prev => prev + 1);
      setHasUpvoted(true);
    }
  };

  return (
    <Card className="transition-all duration-200 hover:shadow-card">
      <CardContent className="pt-6">
        <div className="flex items-start gap-4">
          <button 
            onClick={handleUpvote}
            className={cn(
              "flex flex-col items-center gap-1 p-2 rounded-lg transition-colors",
              hasUpvoted 
                ? "bg-primary/10 text-primary" 
                : "bg-muted hover:bg-muted/80 text-muted-foreground"
            )}
          >
            <ThumbsUp className={cn("h-4 w-4", hasUpvoted && "fill-current")} />
            <span className="text-xs font-medium">{upvotes}</span>
          </button>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-3 mb-2">
              <h3 className="font-semibold">{complaint.title}</h3>
              <Badge variant="outline" className={cn("flex-shrink-0", status.color)}>
                <status.icon className="h-3 w-3 mr-1" />
                {status.label}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
              {complaint.description}
            </p>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <Badge variant="secondary" className={cn("text-xs", categoryStyle.color)}>
                {categoryStyle.label}
              </Badge>
              <span>
                {formatDistanceToNow(complaint.createdAt, { addSuffix: true })}
              </span>
              {complaint.isAnonymous && (
                <span className="flex items-center gap-1">
                  <EyeOff className="h-3 w-3" />
                  Anonymous
                </span>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
