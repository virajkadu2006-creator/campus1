import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MessageSquare, 
  Search, 
  Send, 
  Users, 
  User,
  EyeOff,
  Hash
} from 'lucide-react';
import { cn } from '@/lib/utils';

const conversations = [
  { id: '1', name: 'Vikash Singh', role: 'Senior', lastMessage: 'Check out this DP tutorial', time: '2m ago', unread: 2, online: true },
  { id: '2', name: 'Priya Sharma', role: 'Batchmate', lastMessage: 'Thanks for the notes!', time: '1h ago', unread: 0, online: true },
  { id: '3', name: 'Dr. Amit Kumar', role: 'Faculty', lastMessage: 'Project submission extended', time: '3h ago', unread: 0, online: false },
  { id: '4', name: 'Sneha Gupta', role: 'Senior', lastMessage: 'Good luck for tomorrow!', time: '1d ago', unread: 0, online: false },
];

const groups = [
  { id: '1', name: 'CP Discussion', members: 45, lastMessage: 'Anyone solved todays problem?', time: '5m ago', unread: 8, icon: '💻' },
  { id: '2', name: 'Internship Updates', members: 120, lastMessage: 'Amazon hiring!', time: '30m ago', unread: 3, icon: '💼' },
  { id: '3', name: 'Research Group', members: 23, lastMessage: 'Paper deadline next week', time: '2h ago', unread: 0, icon: '🔬' },
];

const messages = [
  { id: '1', sender: 'Vikash Singh', content: 'Hey! Did you see the new Codeforces round?', time: '10:30 AM', isMe: false },
  { id: '2', sender: 'Me', content: 'Yes! Planning to participate tonight', time: '10:32 AM', isMe: true },
  { id: '3', sender: 'Vikash Singh', content: 'Great! I found this amazing DP tutorial that might help', time: '10:33 AM', isMe: false },
  { id: '4', sender: 'Vikash Singh', content: 'Check out this DP tutorial', time: '10:34 AM', isMe: false },
];

export default function Messages() {
  const [selectedChat, setSelectedChat] = useState(conversations[0]);
  const [messageInput, setMessageInput] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);

  return (
    <div className="h-[calc(100vh-7rem)] animate-fade-in">
      <div className="grid lg:grid-cols-[320px_1fr] h-full gap-6">
        {/* Sidebar */}
        <Card className="flex flex-col overflow-hidden">
          <CardHeader className="pb-3 flex-shrink-0">
            <CardTitle className="text-lg flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-primary" />
              Messages
            </CardTitle>
            <div className="relative mt-3">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search conversations..." className="pl-9" />
            </div>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden p-0">
            <Tabs defaultValue="direct" className="h-full flex flex-col">
              <TabsList className="mx-4 mb-2">
                <TabsTrigger value="direct" className="flex-1 gap-1.5">
                  <User className="h-4 w-4" />
                  Direct
                </TabsTrigger>
                <TabsTrigger value="groups" className="flex-1 gap-1.5">
                  <Hash className="h-4 w-4" />
                  Groups
                </TabsTrigger>
              </TabsList>

              <TabsContent value="direct" className="flex-1 mt-0 overflow-hidden">
                <ScrollArea className="h-full">
                  <div className="space-y-1 p-4 pt-0">
                    {conversations.map((conv) => (
                      <button
                        key={conv.id}
                        onClick={() => setSelectedChat(conv)}
                        className={cn(
                          "w-full flex items-center gap-3 p-3 rounded-lg transition-colors text-left",
                          selectedChat.id === conv.id 
                            ? "bg-primary/10" 
                            : "hover:bg-muted"
                        )}
                      >
                        <div className="relative">
                          <Avatar>
                            <AvatarFallback className="bg-primary/10 text-primary">
                              {conv.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          {conv.online && (
                            <span className="absolute bottom-0 right-0 w-3 h-3 bg-campus-green rounded-full border-2 border-card" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-sm truncate">{conv.name}</span>
                            <span className="text-xs text-muted-foreground">{conv.time}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground truncate">{conv.lastMessage}</span>
                            {conv.unread > 0 && (
                              <Badge className="h-5 w-5 p-0 flex items-center justify-center">
                                {conv.unread}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="groups" className="flex-1 mt-0 overflow-hidden">
                <ScrollArea className="h-full">
                  <div className="space-y-1 p-4 pt-0">
                    {groups.map((group) => (
                      <button
                        key={group.id}
                        className="w-full flex items-center gap-3 p-3 rounded-lg transition-colors text-left hover:bg-muted"
                      >
                        <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-lg">
                          {group.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-sm truncate">{group.name}</span>
                            <span className="text-xs text-muted-foreground">{group.time}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground truncate">{group.lastMessage}</span>
                            {group.unread > 0 && (
                              <Badge className="h-5 w-5 p-0 flex items-center justify-center">
                                {group.unread}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="flex flex-col overflow-hidden">
          {/* Chat Header */}
          <CardHeader className="border-b flex-shrink-0 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback className="bg-primary/10 text-primary">
                    {selectedChat.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold">{selectedChat.name}</h3>
                  <p className="text-xs text-muted-foreground">{selectedChat.role} • Online</p>
                </div>
              </div>
              <Button
                variant={isAnonymous ? "default" : "outline"}
                size="sm"
                onClick={() => setIsAnonymous(!isAnonymous)}
                className="gap-2"
              >
                <EyeOff className="h-4 w-4" />
                Anonymous
              </Button>
            </div>
          </CardHeader>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={cn(
                    "flex",
                    msg.isMe ? "justify-end" : "justify-start"
                  )}
                >
                  <div className={cn(
                    "max-w-[70%] rounded-2xl px-4 py-2",
                    msg.isMe 
                      ? "bg-primary text-primary-foreground rounded-br-md" 
                      : "bg-muted rounded-bl-md"
                  )}>
                    <p className="text-sm">{msg.content}</p>
                    <p className={cn(
                      "text-xs mt-1",
                      msg.isMe ? "text-primary-foreground/70" : "text-muted-foreground"
                    )}>
                      {msg.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Input */}
          <div className="p-4 border-t flex-shrink-0">
            {isAnonymous && (
              <div className="mb-2 px-3 py-2 bg-muted rounded-lg flex items-center gap-2 text-sm text-muted-foreground">
                <EyeOff className="h-4 w-4" />
                Sending as anonymous
              </div>
            )}
            <div className="flex gap-2">
              <Input
                placeholder="Type a message..."
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                className="flex-1"
              />
              <Button size="icon">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
