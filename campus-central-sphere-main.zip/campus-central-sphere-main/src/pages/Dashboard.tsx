import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StatsCard } from '@/components/cards/StatsCard';
import { NoticeCard } from '@/components/cards/NoticeCard';
import { PostCard } from '@/components/cards/PostCard';
import { useAuth } from '@/contexts/AuthContext';
import { notices, posts, messMenu, cpProblems, leaderboard } from '@/data/mockData';
import { 
  Bell, 
  Users, 
  FileText, 
  Code,
  ChevronRight,
  Calendar,
  Star,
  TrendingUp,
  UtensilsCrossed,
  Sparkles
} from 'lucide-react';
import { format } from 'date-fns';

export default function Dashboard() {
  const { user } = useAuth();
  const importantNotices = notices.filter(n => n.isImportant).slice(0, 2);
  const recentPosts = posts.slice(0, 2);
  const todayProblems = cpProblems.filter(p => 
    format(p.date, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd')
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold">
            Welcome back, {user?.name?.split(' ')[0]}! 👋
          </h1>
          <p className="text-muted-foreground mt-1">
            Here's what's happening at IIIT Ranchi today
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1.5 px-3 py-1.5">
            <Sparkles className="h-3.5 w-3.5 text-accent" />
            <span>AI-Powered Feed</span>
          </Badge>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatsCard
          title="Active Notices"
          value={notices.length}
          icon={Bell}
          variant="primary"
          subtitle="2 important"
        />
        <StatsCard
          title="Problems Today"
          value={todayProblems.length}
          icon={Code}
          variant="accent"
          trend={{ value: 12, isPositive: true }}
        />
        <StatsCard
          title="Communities"
          value={6}
          icon={Users}
          subtitle="450+ members"
        />
        <StatsCard
          title="Your Streak"
          value="7 days"
          icon={TrendingUp}
          variant="warning"
        />
      </div>

      {/* Main content grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left column - Feed */}
        <div className="lg:col-span-2 space-y-6">
          {/* Important Notices */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-4">
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                Important Notices
              </CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/notices" className="gap-1">
                  View all <ChevronRight className="h-4 w-4" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent className="space-y-3">
              {importantNotices.map(notice => (
                <NoticeCard key={notice.id} notice={notice} compact />
              ))}
            </CardContent>
          </Card>

          {/* Community Feed */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-4">
              <CardTitle className="text-lg flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Community Feed
              </CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/communities" className="gap-1">
                  Explore <ChevronRight className="h-4 w-4" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentPosts.map(post => (
                <PostCard key={post.id} post={post} />
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Right column - Sidebar widgets */}
        <div className="space-y-6">
          {/* Today's Menu */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <UtensilsCrossed className="h-5 w-5 text-primary" />
                Today's Menu
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">LUNCH</p>
                <p className="text-sm">{messMenu.lunch.join(', ')}</p>
              </div>
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">DINNER</p>
                <p className="text-sm">{messMenu.dinner.join(', ')}</p>
              </div>
              <div className="flex items-center justify-between pt-2 border-t">
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 text-campus-orange fill-campus-orange" />
                  <span className="font-medium">{messMenu.rating}</span>
                  <span className="text-sm text-muted-foreground">/ 5</span>
                </div>
                <span className="text-xs text-muted-foreground">{messMenu.votes} votes</span>
              </div>
              <Button variant="outline" size="sm" className="w-full" asChild>
                <Link to="/mess">Rate today's food</Link>
              </Button>
            </CardContent>
          </Card>

          {/* CP Leaderboard */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Code className="h-5 w-5 text-primary" />
                CP Leaderboard
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboard.slice(0, 5).map((entry) => (
                  <div key={entry.rank} className="flex items-center gap-3">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                      entry.rank === 1 ? 'bg-campus-orange/10 text-campus-orange' :
                      entry.rank === 2 ? 'bg-muted text-muted-foreground' :
                      entry.rank === 3 ? 'bg-campus-orange/5 text-campus-orange/70' :
                      'text-muted-foreground'
                    }`}>
                      {entry.rank}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{entry.name}</p>
                      <p className="text-xs text-muted-foreground">{entry.solved} solved</p>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {entry.rating}
                    </Badge>
                  </div>
                ))}
              </div>
              <Button variant="outline" size="sm" className="w-full mt-4" asChild>
                <Link to="/cp">View full leaderboard</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Upcoming Events */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                Upcoming
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {notices.filter(n => n.deadline).slice(0, 3).map(notice => (
                <div key={notice.id} className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex flex-col items-center justify-center text-primary">
                    <span className="text-xs font-bold">{format(notice.deadline!, 'dd')}</span>
                    <span className="text-[10px]">{format(notice.deadline!, 'MMM')}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium line-clamp-1">{notice.title}</p>
                    <p className="text-xs text-muted-foreground capitalize">{notice.category}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
