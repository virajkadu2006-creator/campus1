import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { messMenu } from '@/data/mockData';
import { 
  UtensilsCrossed, 
  Star, 
  ThumbsUp, 
  ThumbsDown,
  MessageSquare,
  Clock,
  Sun,
  Sunset,
  Moon,
  Coffee
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const mealTimes = [
  { name: 'Breakfast', icon: Coffee, time: '7:30 - 9:30 AM', items: messMenu.breakfast },
  { name: 'Lunch', icon: Sun, time: '12:30 - 2:30 PM', items: messMenu.lunch },
  { name: 'Snacks', icon: Sunset, time: '5:00 - 6:00 PM', items: messMenu.snacks },
  { name: 'Dinner', icon: Moon, time: '7:30 - 9:30 PM', items: messMenu.dinner },
];

export default function Mess() {
  const [selectedRating, setSelectedRating] = useState<number | null>(null);
  const [feedback, setFeedback] = useState('');
  const [hasVoted, setHasVoted] = useState(false);

  const handleRating = (rating: number) => {
    setSelectedRating(rating);
  };

  const submitRating = () => {
    if (selectedRating) {
      setHasVoted(true);
      toast.success('Thanks for your rating!');
    }
  };

  const submitFeedback = () => {
    if (feedback.trim()) {
      toast.success('Feedback submitted anonymously');
      setFeedback('');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold flex items-center gap-2">
            <UtensilsCrossed className="h-6 w-6 text-primary" />
            Mess Community
          </h1>
          <p className="text-muted-foreground mt-1">
            Daily menu, ratings, and feedback
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-lg">
            <Star className="h-5 w-5 text-campus-orange fill-campus-orange" />
            <span className="font-bold text-lg">{messMenu.rating}</span>
            <span className="text-sm text-muted-foreground">/ 5</span>
          </div>
          <Badge variant="secondary">{messMenu.votes} ratings today</Badge>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Today's Menu */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Today's Menu</span>
                <Badge variant="outline" className="font-normal">
                  {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 gap-4">
                {mealTimes.map((meal) => (
                  <div 
                    key={meal.name}
                    className="p-4 rounded-xl bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 rounded-lg bg-primary/10">
                        <meal.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{meal.name}</h3>
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {meal.time}
                        </p>
                      </div>
                    </div>
                    <ul className="space-y-1.5">
                      {meal.items.map((item, idx) => (
                        <li key={idx} className="text-sm flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Rate Today's Food */}
          <Card>
            <CardHeader>
              <CardTitle>Rate Today's Food</CardTitle>
            </CardHeader>
            <CardContent>
              {!hasVoted ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-center gap-2">
                    {[1, 2, 3, 4, 5].map((rating) => (
                      <button
                        key={rating}
                        onClick={() => handleRating(rating)}
                        className={cn(
                          "p-2 rounded-lg transition-all duration-200",
                          selectedRating && selectedRating >= rating
                            ? "text-campus-orange scale-110"
                            : "text-muted-foreground hover:text-campus-orange/70"
                        )}
                      >
                        <Star 
                          className={cn(
                            "h-8 w-8 transition-all",
                            selectedRating && selectedRating >= rating && "fill-campus-orange"
                          )} 
                        />
                      </button>
                    ))}
                  </div>
                  <p className="text-center text-sm text-muted-foreground">
                    {selectedRating ? `You selected ${selectedRating} star${selectedRating > 1 ? 's' : ''}` : 'Tap to rate'}
                  </p>
                  <Button 
                    onClick={submitRating} 
                    disabled={!selectedRating}
                    className="w-full"
                  >
                    Submit Rating
                  </Button>
                </div>
              ) : (
                <div className="text-center py-4">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-campus-green/10 mb-4">
                    <ThumbsUp className="h-8 w-8 text-campus-green" />
                  </div>
                  <p className="font-medium">Thanks for your feedback!</p>
                  <p className="text-sm text-muted-foreground">Your rating helps improve our mess</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Quick Poll */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Quick Poll</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm font-medium">How was today's lunch?</p>
              <div className="space-y-2">
                {[
                  { label: 'Excellent', votes: 45, color: 'bg-campus-green' },
                  { label: 'Good', votes: 32, color: 'bg-campus-blue' },
                  { label: 'Average', votes: 18, color: 'bg-campus-orange' },
                  { label: 'Poor', votes: 5, color: 'bg-destructive' },
                ].map((option) => {
                  const total = 100;
                  const percentage = (option.votes / total) * 100;
                  return (
                    <div key={option.label} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{option.label}</span>
                        <span className="text-muted-foreground">{option.votes}%</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className={cn("h-full rounded-full transition-all", option.color)}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
              <p className="text-xs text-muted-foreground text-center">
                100 students voted today
              </p>
            </CardContent>
          </Card>

          {/* Anonymous Feedback */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Anonymous Feedback
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Share your suggestions or complaints..."
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                className="resize-none"
                rows={4}
              />
              <Button 
                onClick={submitFeedback} 
                disabled={!feedback.trim()}
                variant="outline"
                className="w-full"
              >
                Submit Anonymously
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                Your identity will not be revealed to the mess committee
              </p>
            </CardContent>
          </Card>

          {/* Committee Updates */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Mess Committee</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-sm font-medium">Menu changes next week</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Based on feedback, we're adding more variety to breakfast options.
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-sm font-medium">Special dinner on Sunday</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Celebrating founder's day with a special menu!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
