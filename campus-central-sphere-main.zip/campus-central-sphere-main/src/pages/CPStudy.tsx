import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { cpProblems, leaderboard } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Code, 
  ExternalLink, 
  Trophy, 
  Flame, 
  CheckCircle2, 
  Circle,
  TrendingUp,
  BookOpen,
  Target
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const difficultyColors = {
  easy: 'bg-campus-green/10 text-campus-green border-campus-green/20',
  medium: 'bg-campus-orange/10 text-campus-orange border-campus-orange/20',
  hard: 'bg-destructive/10 text-destructive border-destructive/20',
};

const platformColors = {
  leetcode: 'bg-campus-orange/10 text-campus-orange',
  codeforces: 'bg-campus-blue/10 text-campus-blue',
  codechef: 'bg-campus-purple/10 text-campus-purple',
  hackerrank: 'bg-campus-green/10 text-campus-green',
};

export default function CPStudy() {
  const { user } = useAuth();
  const [solvedProblems, setSolvedProblems] = useState<string[]>(['1', '2', '4']);

  const toggleSolved = (problemId: string) => {
    setSolvedProblems(prev => 
      prev.includes(problemId) 
        ? prev.filter(id => id !== problemId)
        : [...prev, problemId]
    );
  };

  const todayProblems = cpProblems.filter(p => 
    format(p.date, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd')
  );

  const solvedCount = solvedProblems.length;
  const totalProblems = cpProblems.length;
  const progress = (solvedCount / totalProblems) * 100;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold flex items-center gap-2">
            <Code className="h-6 w-6 text-primary" />
            CP & Study Hub
          </h1>
          <p className="text-muted-foreground mt-1">
            Practice, track progress, and climb the leaderboard
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Target className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{solvedCount}</p>
                <p className="text-xs text-muted-foreground">Problems Solved</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-campus-orange/10">
                <Flame className="h-5 w-5 text-campus-orange" />
              </div>
              <div>
                <p className="text-2xl font-bold">7</p>
                <p className="text-xs text-muted-foreground">Day Streak</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-campus-green/10">
                <TrendingUp className="h-5 w-5 text-campus-green" />
              </div>
              <div>
                <p className="text-2xl font-bold">1420</p>
                <p className="text-xs text-muted-foreground">Rating</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-campus-purple/10">
                <Trophy className="h-5 w-5 text-campus-purple" />
              </div>
              <div>
                <p className="text-2xl font-bold">#3</p>
                <p className="text-xs text-muted-foreground">Campus Rank</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Problems Section */}
        <div className="lg:col-span-2 space-y-6">
          <Tabs defaultValue="today">
            <TabsList>
              <TabsTrigger value="today">Today's Problems</TabsTrigger>
              <TabsTrigger value="all">All Problems</TabsTrigger>
              <TabsTrigger value="resources">Resources</TabsTrigger>
            </TabsList>

            <TabsContent value="today" className="mt-4 space-y-4">
              {todayProblems.length > 0 ? (
                todayProblems.map(problem => (
                  <ProblemCard 
                    key={problem.id}
                    problem={problem}
                    isSolved={solvedProblems.includes(problem.id)}
                    onToggle={() => toggleSolved(problem.id)}
                  />
                ))
              ) : (
                <Card className="py-12">
                  <CardContent className="text-center">
                    <Code className="h-12 w-12 text-muted-foreground/40 mx-auto mb-4" />
                    <p className="text-muted-foreground">No problems scheduled for today</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="all" className="mt-4 space-y-4">
              {cpProblems.map(problem => (
                <ProblemCard 
                  key={problem.id}
                  problem={problem}
                  isSolved={solvedProblems.includes(problem.id)}
                  onToggle={() => toggleSolved(problem.id)}
                />
              ))}
            </TabsContent>

            <TabsContent value="resources" className="mt-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <ResourceCard 
                  title="DSA Roadmap"
                  description="Complete roadmap for Data Structures & Algorithms"
                  icon="📚"
                />
                <ResourceCard 
                  title="System Design"
                  description="Learn system design from basics to advanced"
                  icon="🏗️"
                />
                <ResourceCard 
                  title="Interview Prep"
                  description="Top 100 interview questions with solutions"
                  icon="💼"
                />
                <ResourceCard 
                  title="Contest Calendar"
                  description="Upcoming contests on all platforms"
                  icon="📅"
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Leaderboard */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Trophy className="h-5 w-5 text-campus-orange" />
                Campus Leaderboard
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {leaderboard.map((entry, index) => (
                  <div 
                    key={entry.rank} 
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg transition-colors",
                      entry.name === user?.name && "bg-primary/5 border border-primary/20"
                    )}
                  >
                    <span className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center font-bold",
                      entry.rank === 1 && "bg-gradient-to-br from-yellow-400 to-orange-500 text-white",
                      entry.rank === 2 && "bg-gradient-to-br from-gray-300 to-gray-400 text-gray-800",
                      entry.rank === 3 && "bg-gradient-to-br from-orange-300 to-orange-400 text-orange-800",
                      entry.rank > 3 && "bg-muted text-muted-foreground"
                    )}>
                      {entry.rank}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{entry.name}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{entry.solved} solved</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Flame className="h-3 w-3 text-campus-orange" />
                          {entry.streak}d
                        </span>
                      </div>
                    </div>
                    <Badge variant="secondary">{entry.rating}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Progress Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Your Progress</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Weekly Goal</span>
                  <span className="font-medium">{solvedCount}/{totalProblems}</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
              <div className="pt-2 border-t grid grid-cols-3 gap-2 text-center">
                <div>
                  <p className="text-lg font-bold text-campus-green">2</p>
                  <p className="text-xs text-muted-foreground">Easy</p>
                </div>
                <div>
                  <p className="text-lg font-bold text-campus-orange">1</p>
                  <p className="text-xs text-muted-foreground">Medium</p>
                </div>
                <div>
                  <p className="text-lg font-bold text-destructive">0</p>
                  <p className="text-xs text-muted-foreground">Hard</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function ProblemCard({ 
  problem, 
  isSolved, 
  onToggle 
}: { 
  problem: typeof cpProblems[0];
  isSolved: boolean;
  onToggle: () => void;
}) {
  return (
    <Card className={cn(
      "transition-all duration-200",
      isSolved && "bg-campus-green/5 border-campus-green/20"
    )}>
      <CardContent className="py-4">
        <div className="flex items-center gap-4">
          <button onClick={onToggle} className="flex-shrink-0">
            {isSolved ? (
              <CheckCircle2 className="h-6 w-6 text-campus-green" />
            ) : (
              <Circle className="h-6 w-6 text-muted-foreground hover:text-primary transition-colors" />
            )}
          </button>
          <div className="flex-1 min-w-0">
            <p className={cn(
              "font-medium",
              isSolved && "line-through text-muted-foreground"
            )}>
              {problem.title}
            </p>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className={cn("text-xs capitalize", platformColors[problem.platform])}>
                {problem.platform}
              </Badge>
              <Badge variant="outline" className={cn("text-xs capitalize", difficultyColors[problem.difficulty])}>
                {problem.difficulty}
              </Badge>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">
              {problem.solvedBy.length} solved
            </span>
            <Button variant="ghost" size="icon" asChild>
              <a href={problem.url} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ResourceCard({ title, description, icon }: { title: string; description: string; icon: string }) {
  return (
    <Card className="cursor-pointer transition-all duration-200 hover:shadow-card hover:-translate-y-0.5">
      <CardContent className="pt-6">
        <div className="flex items-start gap-3">
          <span className="text-2xl">{icon}</span>
          <div>
            <h3 className="font-semibold">{title}</h3>
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
