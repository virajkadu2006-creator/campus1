import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export function Logo({ size = 'md', showText = true }: LogoProps) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-16 h-16',
  };

  const textSizeClasses = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-3xl',
  };

  return (
    <div className="flex items-center gap-3">
      <div className={`${sizeClasses[size]} relative`}>
        <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
          {/* Central hub */}
          <circle cx="24" cy="24" r="8" className="fill-primary" />
          
          {/* Connected nodes */}
          <circle cx="12" cy="12" r="4" className="fill-accent" />
          <circle cx="36" cy="12" r="4" className="fill-accent" />
          <circle cx="12" cy="36" r="4" className="fill-accent" />
          <circle cx="36" cy="36" r="4" className="fill-accent" />
          
          {/* Connection lines */}
          <line x1="16" y1="20" x2="14" y2="14" strokeWidth="2" className="stroke-primary" opacity="0.6" />
          <line x1="32" y1="20" x2="34" y2="14" strokeWidth="2" className="stroke-primary" opacity="0.6" />
          <line x1="16" y1="28" x2="14" y2="34" strokeWidth="2" className="stroke-primary" opacity="0.6" />
          <line x1="32" y1="28" x2="34" y2="34" strokeWidth="2" className="stroke-primary" opacity="0.6" />
          
          {/* Inner glow */}
          <circle cx="24" cy="24" r="4" className="fill-primary-foreground" />
        </svg>
      </div>
      {showText && (
        <div className="flex flex-col">
          <span className={`font-display font-bold ${textSizeClasses[size]} tracking-tight`}>
            <span className="text-primary">Campus</span>
            <span className="text-accent">One</span>
          </span>
          {size === 'lg' && (
            <span className="text-xs text-muted-foreground tracking-wide">
              One Login. One Platform. One Campus.
            </span>
          )}
        </div>
      )}
    </div>
  );
}
