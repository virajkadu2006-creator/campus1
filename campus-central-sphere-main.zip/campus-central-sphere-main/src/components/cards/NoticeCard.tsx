import React from 'react';
import { Notice } from '@/types';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, AlertTriangle } from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

interface NoticeCardProps {
  notice: Notice;
  compact?: boolean;
}

const categoryStyles: Record<string, string> = {
  academic: 'bg-campus-blue/10 text-campus-blue border-campus-blue/20',
  exams: 'bg-campus-orange/10 text-campus-orange border-campus-orange/20',
  scholarships: 'bg-campus-green/10 text-campus-green border-campus-green/20',
  events: 'bg-campus-purple/10 text-campus-purple border-campus-purple/20',
  general: 'bg-muted text-muted-foreground',
};

export function NoticeCard({ notice, compact = false }: NoticeCardProps) {
  return (
    <Card className={cn(
      "transition-all duration-200 hover:shadow-card",
      notice.isImportant && "border-l-4 border-l-campus-orange"
    )}>
      <CardHeader className={cn("pb-2", compact && "p-4")}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              {notice.isImportant && (
                <AlertTriangle className="h-4 w-4 text-campus-orange flex-shrink-0" />
              )}
              <Badge variant="outline" className={cn("text-xs capitalize", categoryStyles[notice.category])}>
                {notice.category}
              </Badge>
            </div>
            <h3 className={cn(
              "font-semibold leading-tight",
              compact ? "text-sm line-clamp-2" : "text-base"
            )}>
              {notice.title}
            </h3>
          </div>
        </div>
      </CardHeader>
      <CardContent className={cn(compact && "p-4 pt-0")}>
        {!compact && (
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
            {notice.content}
          </p>
        )}
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {formatDistanceToNow(notice.createdAt, { addSuffix: true })}
          </span>
          {notice.deadline && (
            <span className="flex items-center gap-1 text-campus-orange">
              <Calendar className="h-3 w-3" />
              Due: {format(notice.deadline, 'MMM d')}
            </span>
          )}
        </div>
        {!compact && (
          <p className="text-xs text-muted-foreground mt-2">
            Posted by {notice.author}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
