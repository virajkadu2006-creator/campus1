import React from 'react';
import { Community } from '@/types';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CommunityCardProps {
  community: Community;
}

const categoryColors: Record<string, string> = {
  tech: 'bg-campus-blue/10 text-campus-blue',
  cultural: 'bg-campus-purple/10 text-campus-purple',
  sports: 'bg-campus-green/10 text-campus-green',
  academic: 'bg-campus-orange/10 text-campus-orange',
};

export function CommunityCard({ community }: CommunityCardProps) {
  return (
    <Card className="transition-all duration-200 hover:shadow-card hover:-translate-y-0.5 group">
      <CardContent className="pt-6">
        <div className="flex items-start gap-4">
          <div className={cn(
            "h-14 w-14 rounded-xl flex items-center justify-center text-2xl",
            categoryColors[community.category]
          )}>
            {community.icon}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-base mb-1 group-hover:text-primary transition-colors">
              {community.name}
            </h3>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {community.description}
            </p>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-0 flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-muted-foreground">
          <Users className="h-4 w-4" />
          <span className="text-sm">{community.memberCount} members</span>
        </div>
        <Badge variant="outline" className={cn("capitalize text-xs", categoryColors[community.category])}>
          {community.category}
        </Badge>
      </CardFooter>
    </Card>
  );
}
